package com.neoris.bitacoras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeorisBitacorasBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
