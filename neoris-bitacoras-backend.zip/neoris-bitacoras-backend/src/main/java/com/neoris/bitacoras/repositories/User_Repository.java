package com.neoris.bitacoras.repositories;

import com.neoris.bitacoras.model.User;
import com.neoris.bitacoras.model.Workstation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Set;

public interface User_Repository extends JpaRepository<User,Integer> {

    public User findById(int idUser) throws Exception;
    public Set<User> findByWorkstation(Workstation workstation) throws Exception;

}
