package com.neoris.bitacoras.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

@Entity
@Table(name = "BINNACLES_PROJECTS",
       schema = "binnacle_activities")

public class Binnacle_Project {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_bin_pro", length = 10)
    private int idBinPro;
    @JoinColumn(name = "id_project")
    @ManyToOne(fetch = FetchType.EAGER)
    @JsonManagedReference
    private Project project;
    @JoinColumn(name = "id_binnacle")
    @ManyToOne(fetch = FetchType.EAGER)
    @JsonManagedReference
    private Binnacle binnacle;



    public int getIdBinPro() {
        return idBinPro;
    }

    public void setIdBinPro(int idBinPro) {
        this.idBinPro = idBinPro;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Binnacle getBinnacle() {
        return binnacle;
    }

    public void setBinnacle(Binnacle binnacle) {
        this.binnacle = binnacle;
    }



    public Binnacle_Project() {
    }
}
