package com.neoris.bitacoras.controllers;

import com.neoris.bitacoras.model.Activitie;
import com.neoris.bitacoras.services.Activitie_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/ACTIVITIES")
@CrossOrigin("*")
public class Activitie_Controller {

    @Autowired
    private Activitie_Service activitieService;

    @PostMapping("/")
    public ResponseEntity<Activitie> saveActivitie(@RequestBody Activitie activitie) throws Exception{
        Activitie activitieSave = activitieService.saveActivitie(activitie);
        return ResponseEntity.ok(activitieSave);
    }

    @GetMapping("/")
    public ResponseEntity<?> listActivities() throws Exception{
        return ResponseEntity.ok(activitieService.listActivities());
    }

}
