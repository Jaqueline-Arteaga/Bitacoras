package com.neoris.bitacoras.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "BINNACLES",
       schema = "binnacle_activities",
       uniqueConstraints = {@UniqueConstraint(columnNames = {"name"})})

public class Binnacle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_binnacle", length = 10)
    private int idBinnacle;
    @Column(name = "name", nullable = false, length = 150)
    private String name;
    @Column(name = "type", nullable = false, length = 150)
    private String type;
    @Column(name = "archive", nullable = false, columnDefinition = "BLOB")
    private String archive;



    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "binnacle")
    @JsonBackReference
    private Set<Binnacle_Project> binnaclesProjects= new HashSet<>();



    public int getIdBinnacle() {
        return idBinnacle;
    }

    public void setIdBinnacle(int idBinnacle) {
        this.idBinnacle = idBinnacle;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getArchive() {
        return archive;
    }

    public void setArchive(String archive) {
        this.archive = archive;
    }

    public Set<Binnacle_Project> getBinnaclesProjects() {
        return binnaclesProjects;
    }

    public void setBinnaclesProjects(Set<Binnacle_Project> binnaclesProjects) {
        this.binnaclesProjects = binnaclesProjects;
    }



    public Binnacle() {
    }
}
