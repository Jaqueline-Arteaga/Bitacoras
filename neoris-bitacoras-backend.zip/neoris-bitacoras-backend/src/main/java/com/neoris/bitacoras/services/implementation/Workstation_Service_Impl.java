package com.neoris.bitacoras.services.implementation;

import com.neoris.bitacoras.model.Workstation;
import com.neoris.bitacoras.repositories.Workstation_Repository;
import com.neoris.bitacoras.services.Workstation_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class Workstation_Service_Impl implements Workstation_Service {

    @Autowired
    private Workstation_Repository workstationRepository;

    @Override
    public Workstation saveWorkstation(Workstation workstation) throws Exception {
        return workstationRepository.save(workstation);
    }

    @Override
    public Set<Workstation> listWorkstations() throws Exception {
        return new LinkedHashSet<>(workstationRepository.findAll());
    }

}
