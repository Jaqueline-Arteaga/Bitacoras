package com.neoris.bitacoras.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ACTIVITIES",
       schema = "binnacle_activities")

public class Activitie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_activitie", length = 10)
    private int idActivitie;
    @Column(name = "description", nullable = false, columnDefinition = "LONGTEXT")
    private String description;
    @Column(name = "date_start", nullable = false, columnDefinition = "DATE")
    @JsonFormat(pattern = "YYYY-MM-dd")
    private Date dateStart;
    @Column(name = "date_end", nullable = false, columnDefinition = "DATE")
    @JsonFormat(pattern = "YYYY-MM-dd")
    private Date dateEnd;
    @Column(name = "working_hours", nullable = false, length = 10)
    private int workingHours;



    @JoinColumn(name = "id_pro_man")
    @ManyToOne(fetch = FetchType.EAGER)
    @JsonManagedReference
    private Project_Manager projectManager;
    @JoinColumn(name = "id_provider")
    @ManyToOne(fetch = FetchType.EAGER)
    @JsonManagedReference
    private Provider provider;
    @JoinColumn(name = "id_area")
    @ManyToOne(fetch = FetchType.EAGER)
    @JsonManagedReference
    private Area area;



    public int getIdActivitie() {
        return idActivitie;
    }

    public void setIdActivitie(int idActivitie) {
        this.idActivitie = idActivitie;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDateStart() {
        return dateStart;
    }

    public void setDateStart(Date dateStart) {
        this.dateStart = dateStart;
    }

    public Date getDateEnd() {
        return dateEnd;
    }

    public void setDateEnd(Date dateEnd) {
        this.dateEnd = dateEnd;
    }

    public int getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(int workingHours) {
        this.workingHours = workingHours;
    }

    public Project_Manager getProjectManager() {
        return projectManager;
    }

    public void setProjectManager(Project_Manager projectManager) {
        this.projectManager = projectManager;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }



    public Activitie() {
    }
}
