package com.neoris.bitacoras.repositories;

import com.neoris.bitacoras.model.Binnacle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Binnacle_Repository extends JpaRepository<Binnacle,Integer> {

    public Binnacle findById(int idBinnacle) throws Exception;

}
