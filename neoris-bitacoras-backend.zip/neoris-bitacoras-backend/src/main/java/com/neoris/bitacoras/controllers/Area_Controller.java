package com.neoris.bitacoras.controllers;

import com.neoris.bitacoras.model.Area;
import com.neoris.bitacoras.services.Area_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/AREAS")
@CrossOrigin("*")
public class Area_Controller {

    @Autowired
    private Area_Service areaService;

    @PostMapping("/")
    public ResponseEntity<Area> saveArea(@RequestBody Area area) throws Exception{
        Area areaSave = areaService.saveArea(area);
        return ResponseEntity.ok(areaSave);
    }

    @GetMapping("/{id_area}")
    public Area consultArea(@PathVariable("id_area") int idArea) throws Exception{
        return areaService.consultArea(idArea);
    }

    @GetMapping("/")
    public ResponseEntity<?> listAreas() throws Exception{
        return ResponseEntity.ok(areaService.listAreas());
    }

    @PutMapping("/{id_area}")
    public Area updateArea(@RequestBody Area area, @PathVariable("id_area") int idArea) throws Exception{
        return areaService.updateArea(area,idArea);
    }

    @DeleteMapping("/{id_area}")
    public void deleteArea(@PathVariable("id_area") int idArea) throws Exception{
        areaService.deleteArea(idArea);
    }

}
