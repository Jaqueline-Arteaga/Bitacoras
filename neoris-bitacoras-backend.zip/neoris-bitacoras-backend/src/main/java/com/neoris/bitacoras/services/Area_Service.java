package com.neoris.bitacoras.services;

import com.neoris.bitacoras.model.Area;

import java.util.Set;

public interface Area_Service {

    public Area saveArea(Area area) throws Exception;
    public Area updateArea(Area area, int idArea) throws Exception;
    public Set<Area> listAreas() throws Exception;
    public Area consultArea(int idArea) throws Exception;
    public void deleteArea(int idArea) throws Exception;

}
