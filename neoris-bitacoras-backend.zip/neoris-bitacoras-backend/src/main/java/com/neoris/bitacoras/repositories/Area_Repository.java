package com.neoris.bitacoras.repositories;

import com.neoris.bitacoras.model.Area;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Area_Repository extends JpaRepository<Area,Integer> {

    public Area findById(int idArea) throws Exception;

}
