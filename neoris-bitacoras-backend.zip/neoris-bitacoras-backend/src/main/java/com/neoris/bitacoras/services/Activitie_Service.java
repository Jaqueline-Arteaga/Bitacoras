package com.neoris.bitacoras.services;

import com.neoris.bitacoras.model.Activitie;
import java.util.Set;

public interface Activitie_Service {

    public Activitie saveActivitie(Activitie activitie) throws Exception;
    public Set<Activitie> listActivities() throws Exception;

}
