package com.neoris.bitacoras.controllers;

import com.neoris.bitacoras.model.Binnacle_Project;
import com.neoris.bitacoras.services.Binnacle_Project_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/BINNACLES_PROJECTS")
@CrossOrigin("*")
public class Binnacle_Project_Controller {

    @Autowired
    private Binnacle_Project_Service binnacleProjectService;

    @PostMapping("/")
    public ResponseEntity<Binnacle_Project> saveBinnacleProject(@RequestBody Binnacle_Project binnacleProject) throws Exception{
        Binnacle_Project binnacleProjectSave = binnacleProjectService.saveBinnacleProject(binnacleProject);
        return ResponseEntity.ok(binnacleProjectSave);
    }

    @GetMapping("/")
    public ResponseEntity<?> listBinnacles_Projects() throws Exception{
        return ResponseEntity.ok(binnacleProjectService.listBinnaclesProjects());
    }

}
