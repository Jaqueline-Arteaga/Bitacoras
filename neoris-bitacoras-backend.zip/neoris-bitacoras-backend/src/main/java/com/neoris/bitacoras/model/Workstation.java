package com.neoris.bitacoras.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "WORKSTATIONS",
       schema = "binnacle_activities",
       uniqueConstraints = {@UniqueConstraint(columnNames = {"description"})})

public class Workstation implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_workstation", length = 10)
    private int idWorkstation;
    @Column(name = "description", nullable = false, length = 150)
    private String description;



    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "workstation")
    //@JsonBackReference
    @JsonIgnore
    private Set<User> users = new HashSet<>();



    public int getIdWorkstation() {
        return idWorkstation;
    }

    public void setIdWorkstation(int idWorkstation) {
        this.idWorkstation = idWorkstation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<User> getUsers() {
        return users;
    }

    public void setUsers(Set<User> users) {
        this.users = users;
    }



    public Workstation() {
    }
}
