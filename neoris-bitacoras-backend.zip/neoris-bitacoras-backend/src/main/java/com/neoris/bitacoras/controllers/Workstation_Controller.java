package com.neoris.bitacoras.controllers;

import com.neoris.bitacoras.model.Workstation;
import com.neoris.bitacoras.services.Workstation_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/WORKSTATIONS")
@CrossOrigin("*")
public class Workstation_Controller {

    @Autowired
    private Workstation_Service workstationService;


    @PostMapping("/")
    public ResponseEntity<Workstation> saveWorkstation(@RequestBody Workstation workstation) throws Exception{
        Workstation workstationSave = workstationService.saveWorkstation(workstation);
        return ResponseEntity.ok(workstationSave);
    }

    @GetMapping("/")
    public ResponseEntity<?> listWorkstations() throws Exception{
        return ResponseEntity.ok(workstationService.listWorkstations());
    }

}
