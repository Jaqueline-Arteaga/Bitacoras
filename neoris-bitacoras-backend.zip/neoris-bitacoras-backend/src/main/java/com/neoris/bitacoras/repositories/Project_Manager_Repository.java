package com.neoris.bitacoras.repositories;

import com.neoris.bitacoras.model.Project_Manager;
import com.neoris.bitacoras.model.Project;
import com.neoris.bitacoras.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Set;

public interface Project_Manager_Repository extends JpaRepository<Project_Manager,Integer> {

    public Project_Manager findById(int idProMan) throws Exception;
    public Set<Project_Manager> findByProject(Project idProject) throws Exception;
    public Set<Project_Manager> findByUser(User idUser) throws Exception;

}
