package com.neoris.bitacoras.services.implementation;

import com.neoris.bitacoras.model.Project_Manager;
import com.neoris.bitacoras.repositories.Project_Manager_Repository;
import com.neoris.bitacoras.services.Project_Manager_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class Project_Manager_Service_Impl implements Project_Manager_Service {

    @Autowired
    private Project_Manager_Repository projectManagerRepository;

    @Override
    public Project_Manager saveProjectAssignment(Project_Manager projectManager) throws Exception {
        return projectManagerRepository.save(projectManager);
    }

    @Override
    public Set<Project_Manager> listAssignments() throws Exception {
        return new LinkedHashSet<>(projectManagerRepository.findAll());
    }

}
