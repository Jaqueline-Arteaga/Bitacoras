package com.neoris.bitacoras.controllers;

import com.neoris.bitacoras.model.Project;
import com.neoris.bitacoras.services.Project_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/PROJECTS")
@CrossOrigin("*")
public class Project_Controller {

    @Autowired
    private Project_Service projectService;

    @PostMapping("/")
    public ResponseEntity<Project> saveProject(@RequestBody Project project) throws Exception{
        Project projectSave = projectService.saveProject(project);
        return ResponseEntity.ok(projectSave);
    }

    @GetMapping("/{id_project}")
    public Project consultProject(@PathVariable("id_project") int idProject) throws Exception{
        return projectService.consultProject(idProject);
    }

    @GetMapping("/")
    public ResponseEntity<?> listProjects() throws Exception{
        return ResponseEntity.ok(projectService.listProjects());
    }

    @PutMapping("/{id_project}")
    public Project updateProject(@RequestBody Project project, @PathVariable("id_project") int idProject) throws Exception{
        return projectService.updateProject(project,idProject);
    }

    @DeleteMapping("/{id_project}")
    public void deleteProject(@PathVariable("id_project") int idProject) throws Exception{
        projectService.deleteProject(idProject);
    }

}
