package com.neoris.bitacoras.repositories;

import com.neoris.bitacoras.model.Workstation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Workstation_Repository extends JpaRepository<Workstation,Integer> {

}
