package com.neoris.bitacoras.repositories;

import com.neoris.bitacoras.model.Activitie;
import com.neoris.bitacoras.model.Area;
import com.neoris.bitacoras.model.Project_Manager;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Set;

public interface Activitie_Repository extends JpaRepository<Activitie,Integer> {

    public Activitie findById(int idActivitie) throws Exception;
    public Set<Activitie> findByArea(Area idArea) throws Exception;
    public Set<Activitie> findByProjectManager(Project_Manager idProMan) throws Exception;

}
