package com.neoris.bitacoras.controllers;

import com.neoris.bitacoras.model.User;
import com.neoris.bitacoras.services.User_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/USERS")
@CrossOrigin("*")
public class User_Controller {

    @Autowired
    private User_Service userService;

    @PostMapping("/")
    public ResponseEntity<User> saveUser(@RequestBody User user) throws Exception{
        User userSave = userService.saveUser(user);
        return ResponseEntity.ok(userSave);
    }

    @GetMapping("/{id_user}")
    public User consultUser(@PathVariable("id_user") int idUser) throws Exception{
        return userService.consultUser(idUser);
    }

    @GetMapping("/")
    public ResponseEntity<?> listUsers() throws Exception{
        return ResponseEntity.ok(userService.listUsers());
    }

    @PutMapping("/{id_user}")
    public User updateUser(@RequestBody User user, @PathVariable("id_user") int idUser) throws Exception{
        return userService.updateUser(user,idUser);
    }

    @DeleteMapping("/{id_user}")
    public void deleteUser(@PathVariable("id_user") int idUser) throws Exception{
        userService.deleteUser(idUser);
    }

}
