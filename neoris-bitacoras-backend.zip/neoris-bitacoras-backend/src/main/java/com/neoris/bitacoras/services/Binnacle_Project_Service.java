package com.neoris.bitacoras.services;

import com.neoris.bitacoras.model.Binnacle_Project;
import java.util.Set;

public interface Binnacle_Project_Service {

    public Binnacle_Project saveBinnacleProject(Binnacle_Project binnacleProject) throws Exception;
    public Set<Binnacle_Project> listBinnaclesProjects() throws Exception;

}
