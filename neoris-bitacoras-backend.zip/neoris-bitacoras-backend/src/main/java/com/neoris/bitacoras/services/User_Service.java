package com.neoris.bitacoras.services;

import com.neoris.bitacoras.model.User;
import com.neoris.bitacoras.model.Workstation;

import java.util.Set;

public interface User_Service {

    public User saveUser(User user) throws Exception;
    public User updateUser(User user, int idUser) throws Exception;
    public Set<User> listUsers() throws Exception;
    public User consultUser(int idUser) throws Exception;
    public void deleteUser(int idUser) throws Exception;
    public Set<User> listUsersByWorkstation(Workstation workstation) throws Exception;

}
