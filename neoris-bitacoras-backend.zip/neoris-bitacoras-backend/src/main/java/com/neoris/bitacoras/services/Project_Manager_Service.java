package com.neoris.bitacoras.services;

import com.neoris.bitacoras.model.Project_Manager;

import java.util.Set;

public interface Project_Manager_Service {

    public Project_Manager saveProjectAssignment(Project_Manager projectManager) throws Exception;
    public Set<Project_Manager> listAssignments() throws Exception;

    //public Project_Manager saveProjectAssignment(int id_project, int id_user, int id_rol) throws Exception;
    //public Project_Manager updateAssignment(Project_Manager activity_manager, int id_act_man, int id_project, int id_user, int id_rol) throws Exception;
    //public Set<Project_Manager> listAssignments() throws Exception;
    //public Project_Manager consultAssignment(int id_act_man) throws Exception;
    //public void deleteUser(int id_act_man) throws Exception;
    //public Set<Project_Manager> listUsersByProjects(Project project) throws Exception;

}
