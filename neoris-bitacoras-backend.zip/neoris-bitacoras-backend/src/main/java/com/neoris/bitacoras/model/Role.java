package com.neoris.bitacoras.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "ROLES",
       schema = "binnacle_activities",
       uniqueConstraints = {@UniqueConstraint(columnNames = {"description"})})

public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_role", length = 10)
    private int idRole;
    @Column(name = "description", nullable = false, length = 150)
    private String description;



    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "role")
    @JsonBackReference
    private Set<Project_Manager> projectsManager = new HashSet<>();



    public int getIdRole() {
        return idRole;
    }

    public void setIdRole(int idRole) {
        this.idRole = idRole;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<Project_Manager> getProjectsManager() {
        return projectsManager;
    }

    public void setProjectsManager(Set<Project_Manager> projectsManager) {
        this.projectsManager = projectsManager;
    }



    public Role() {
    }
}
