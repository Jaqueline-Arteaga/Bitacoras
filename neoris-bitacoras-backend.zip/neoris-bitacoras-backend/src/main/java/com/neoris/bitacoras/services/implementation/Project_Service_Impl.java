package com.neoris.bitacoras.services.implementation;

import com.neoris.bitacoras.model.Project;
import com.neoris.bitacoras.repositories.Project_Repository;
import com.neoris.bitacoras.services.Project_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class Project_Service_Impl implements Project_Service {

    @Autowired
    private Project_Repository projectRepository;


    @Override
    public Project saveProject(Project project) throws Exception {
        return projectRepository.save(project);
    }

    @Override
    public Project updateProject(Project project, int idProject) throws Exception {
        Project projectUpdate = projectRepository.findById(idProject);
        project.setIdProject(projectUpdate.getIdProject());
        return projectRepository.save(project);
    }

    @Override
    public Set<Project> listProjects() throws Exception {
        return new LinkedHashSet<>(projectRepository.findAll());
    }

    @Override
    public Project consultProject(int idProject) throws Exception {
        return projectRepository.findById(idProject);
    }

    @Override
    public void deleteProject(int idProject) throws Exception {
        Project project= new Project();
        project.setIdProject(idProject);
        projectRepository.delete(project);
    }

}
