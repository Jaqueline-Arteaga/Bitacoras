package com.neoris.bitacoras.controllers;

import com.neoris.bitacoras.model.Project_Manager;
import com.neoris.bitacoras.services.Project_Manager_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/PROJECT_MANAGER")
@CrossOrigin("*")
public class Project_Manager_Controller {

    @Autowired
    private Project_Manager_Service projectManagerService;

    @PostMapping("/")
    public ResponseEntity<Project_Manager> saveProjectAssignment(@RequestBody Project_Manager project_manager) throws Exception{
        Project_Manager project_managerSave = projectManagerService.saveProjectAssignment(project_manager);
        return ResponseEntity.ok(project_managerSave);
    }

    @GetMapping("/")
    public ResponseEntity<?> listAssignments() throws Exception{
        return ResponseEntity.ok(projectManagerService.listAssignments());
    }

}
