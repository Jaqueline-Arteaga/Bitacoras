package com.neoris.bitacoras.services;

import com.neoris.bitacoras.model.Role;
import java.util.Set;

public interface Role_Service {

    public Role saveRole(Role role) throws Exception;
    public Set<Role> listRoles() throws Exception;

}
