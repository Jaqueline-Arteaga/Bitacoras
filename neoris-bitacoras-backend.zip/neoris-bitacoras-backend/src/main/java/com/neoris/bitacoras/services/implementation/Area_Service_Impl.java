package com.neoris.bitacoras.services.implementation;

import com.neoris.bitacoras.model.Area;
import com.neoris.bitacoras.repositories.Area_Repository;
import com.neoris.bitacoras.services.Area_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class Area_Service_Impl implements Area_Service {

    @Autowired
    private Area_Repository areaRepository;

    @Override
    public Area saveArea(Area area) throws Exception {
        return areaRepository.save(area);
    }

    @Override
    public Area updateArea(Area area, int idArea) throws Exception {
        Area areaUpdate = areaRepository.findById(idArea);
        area.setIdArea(areaUpdate.getIdArea());
        return areaRepository.save(area);
    }

    @Override
    public Set<Area> listAreas() throws Exception {
        return new LinkedHashSet<>(areaRepository.findAll());
    }

    @Override
    public Area consultArea(int idArea) throws Exception {
        return areaRepository.findById(idArea);
    }

    @Override
    public void deleteArea(int idArea) throws Exception {
        Area area= new Area();
        area.setIdArea(idArea);
        areaRepository.delete(area);
    }

}
