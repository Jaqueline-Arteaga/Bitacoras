package com.neoris.bitacoras.controllers;


import com.neoris.bitacoras.model.Provider;
import com.neoris.bitacoras.services.Provider_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/PROVIDERS")
@CrossOrigin("*")
public class Provider_Controller {

    @Autowired
    private Provider_Service providerService;

    @PostMapping("/")
    public ResponseEntity<Provider> saveProvider(@RequestBody Provider provider) throws Exception{
        Provider providerSave = providerService.saveProvider(provider);
        return ResponseEntity.ok(providerSave);
    }

    @GetMapping("/{id_provider}")
    public Provider consultProvider(@PathVariable("id_provider") int idProvider) throws Exception{
        return providerService.consultProvider(idProvider);
    }

    @GetMapping("/")
    public ResponseEntity<?> listProviders() throws Exception{
        return ResponseEntity.ok(providerService.listProviders());
    }

    @PutMapping("/{id_provider}")
    public Provider updateProvider(@RequestBody Provider provider, @PathVariable("id_provider") int idProvider) throws Exception{
        return providerService.updateProvider(provider,idProvider);
    }

    @DeleteMapping("/{id_provider}")
    public void deleteProvider(@PathVariable("id_provider") int idProvider) throws Exception{
        providerService.deleteProvider(idProvider);
    }

}
