package com.neoris.bitacoras.services;

import com.neoris.bitacoras.model.Binnacle;

import java.util.Set;

public interface Binnacle_Service {

    public Binnacle saveBinnacle(Binnacle binnacle) throws Exception;
    public Binnacle updateBinnacle(Binnacle binnacle, int idBinnacle) throws Exception;
    public Set<Binnacle> listBinnacles() throws Exception;
    public Binnacle consultBinnacle(int idBinnacle) throws Exception;
    public void deleteBinnacle(int idBinnacle) throws Exception;

}
