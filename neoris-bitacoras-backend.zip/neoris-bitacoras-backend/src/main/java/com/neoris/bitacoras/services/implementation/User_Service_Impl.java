package com.neoris.bitacoras.services.implementation;

import com.neoris.bitacoras.model.User;
import com.neoris.bitacoras.model.Workstation;
import com.neoris.bitacoras.repositories.User_Repository;
import com.neoris.bitacoras.services.User_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.LinkedHashSet;
import java.util.Set;


@Service
public class User_Service_Impl implements User_Service {

    @Autowired
    private User_Repository userRepository;

    @Override
    public User saveUser(User user) throws Exception {
        return userRepository.save(user);
    }

    @Override
    public User updateUser(User user, int idUser) throws Exception {
        User userUpdate = userRepository.findById(idUser);
        user.setIdUser(userUpdate.getIdUser());
        return userRepository.save(user);
    }

    @Override
    public Set<User> listUsers() throws Exception {
        return new LinkedHashSet<>(userRepository.findAll());
    }

    @Override
    public User consultUser(int idUser) throws Exception {
        return userRepository.findById(idUser);
    }

    @Override
    public void deleteUser(int idUser) throws Exception{
        User user= new User();
        user.setIdUser(idUser);
        userRepository.delete(user);
    }

    @Override
    public Set<User> listUsersByWorkstation(Workstation workstation) throws Exception {
        return userRepository.findByWorkstation(workstation);
    }

}
