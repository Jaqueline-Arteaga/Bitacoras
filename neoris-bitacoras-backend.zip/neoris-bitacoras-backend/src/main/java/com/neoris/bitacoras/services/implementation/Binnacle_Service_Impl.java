package com.neoris.bitacoras.services.implementation;


import com.neoris.bitacoras.model.Binnacle;
import com.neoris.bitacoras.repositories.Binnacle_Repository;
import com.neoris.bitacoras.services.Binnacle_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class Binnacle_Service_Impl implements Binnacle_Service {

    @Autowired
    private Binnacle_Repository binnacleRepository;


    @Override
    public Binnacle saveBinnacle(Binnacle binnacle) throws Exception {
        return binnacleRepository.save(binnacle);
    }

    @Override
    public Binnacle updateBinnacle(Binnacle binnacle, int idBinnacle) throws Exception {
        Binnacle binnacleUpdate = binnacleRepository.findById(idBinnacle);
        binnacle.setIdBinnacle(binnacleUpdate.getIdBinnacle());
        return binnacleRepository.save(binnacle);
    }

    @Override
    public Set<Binnacle> listBinnacles() throws Exception {
        return new LinkedHashSet<>(binnacleRepository.findAll());
    }

    @Override
    public Binnacle consultBinnacle(int idBinnacle) throws Exception {
        return binnacleRepository.findById(idBinnacle);
    }

    @Override
    public void deleteBinnacle(int idBinnacle) throws Exception {
        Binnacle binnacle= new Binnacle();
        binnacle.setIdBinnacle(idBinnacle);
        binnacleRepository.delete(binnacle);
    }
}
