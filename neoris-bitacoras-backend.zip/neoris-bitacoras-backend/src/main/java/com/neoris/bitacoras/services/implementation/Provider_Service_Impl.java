package com.neoris.bitacoras.services.implementation;

import com.neoris.bitacoras.model.Provider;
import com.neoris.bitacoras.repositories.Provider_Repository;
import com.neoris.bitacoras.services.Provider_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class Provider_Service_Impl implements Provider_Service {

    @Autowired
    private Provider_Repository providerRepository;

    @Override
    public Provider saveProvider(Provider provider) throws Exception {
        return providerRepository.save(provider);
    }

    @Override
    public Provider updateProvider(Provider provider, int idProvider) throws Exception {
        Provider providerUpdate = providerRepository.findById(idProvider);
        provider.setIdProvider(providerUpdate.getIdProvider());
        return providerRepository.save(provider);
    }

    @Override
    public Set<Provider> listProviders() throws Exception {
        return new LinkedHashSet<>(providerRepository.findAll());
    }

    @Override
    public Provider consultProvider(int idProvider) throws Exception {
        return providerRepository.findById(idProvider);
    }

    @Override
    public void deleteProvider(int idProvider) throws Exception {
        Provider provider= new Provider();
        provider.setIdProvider(idProvider);
        providerRepository.delete(provider);
    }
}
