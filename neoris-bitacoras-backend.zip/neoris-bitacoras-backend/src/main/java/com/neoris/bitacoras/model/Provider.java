package com.neoris.bitacoras.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "PROVIDERS",
       schema = "binnacle_activities",
       uniqueConstraints = {@UniqueConstraint(columnNames = {"name"})})

public class Provider {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_provider", length = 10)
    private int idProvider;
    @Column(name = "name", nullable = false, length = 150)
    private String name;



    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "provider")
    @JsonBackReference
    private Set<Activitie> activities= new HashSet<>();



    public int getIdProvider() {
        return idProvider;
    }

    public void setIdProvider(int idProvider) {
        this.idProvider = idProvider;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Activitie> getActivities() {
        return activities;
    }

    public void setActivities(Set<Activitie> activities) {
        this.activities = activities;
    }



    public Provider() {
    }
}
