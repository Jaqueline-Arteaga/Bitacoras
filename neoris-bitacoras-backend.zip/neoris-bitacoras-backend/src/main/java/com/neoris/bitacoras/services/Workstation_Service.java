package com.neoris.bitacoras.services;

import com.neoris.bitacoras.model.Workstation;
import java.util.Set;

public interface Workstation_Service {

    public Workstation saveWorkstation(Workstation workstation) throws Exception;
    public Set<Workstation> listWorkstations() throws Exception;

}
