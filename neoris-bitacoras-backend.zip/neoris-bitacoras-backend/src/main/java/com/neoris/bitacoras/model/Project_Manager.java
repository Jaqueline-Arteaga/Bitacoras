package com.neoris.bitacoras.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "PROJECT_MANAGER",
       schema = "binnacle_activities")

public class Project_Manager {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pro_man", length = 10)
    private int idProMan;
    @JoinColumn(name = "id_user")
    @ManyToOne(fetch = FetchType.EAGER)
    @JsonManagedReference
    private User user;
    @JoinColumn(name = "id_project")
    @ManyToOne(fetch = FetchType.EAGER)
    @JsonManagedReference
    private Project project;
    @JoinColumn(name = "id_role")
    @ManyToOne
    @JsonManagedReference
    private Role role;



    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "projectManager")
    @JsonBackReference
    private Set<Activitie> activities= new HashSet<>();



    public int getIdProMan() {
        return idProMan;
    }

    public void setIdProMan(int idProMan) {
        this.idProMan = idProMan;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Set<Activitie> getActivities() {
        return activities;
    }

    public void setActivities(Set<Activitie> activities) {
        this.activities = activities;
    }



    public Project_Manager() {
    }

}
