package com.neoris.bitacoras.repositories;

import com.neoris.bitacoras.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Role_Repository extends JpaRepository<Role,Integer> {
}
