package com.neoris.bitacoras.model;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "USERS",
       schema = "binnacle_activities",
       uniqueConstraints = {@UniqueConstraint(columnNames = {"mail"})})

@JsonIdentityInfo( generator = ObjectIdGenerators.PropertyGenerator.class, property = "idUser")
public class User implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_user", length = 10)
    private int idUser;
    @Column(name = "name", nullable = false, length = 150)
    private String name;
    @Column(name = "p_last_name", nullable = false, length = 150)
    private String pLastName;
    @Column(name = "m_last_name", nullable = false, length = 150)
    private String mLastName;
    @Column(name = "mail", nullable = false, length = 150)
    private String mail;
    @Column(name = "password", nullable = false, columnDefinition = "LONGTEXT")
    private String password;
    @JoinColumn(name = "id_workstation")
    @ManyToOne(fetch = FetchType.LAZY)
    //@JsonManagedReference
    //@JsonIgnore
    private Workstation workstation;



    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "user")
    //@JsonBackReference
    private Set<Project_Manager> projectsManager = new HashSet<>();


    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getpLastName() {
        return pLastName;
    }

    public void setpLastName(String pLastName) {
        this.pLastName = pLastName;
    }

    public String getmLastName() {
        return mLastName;
    }

    public void setmLastName(String mLastName) {
        this.mLastName = mLastName;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Workstation getWorkstation() {
        return workstation;
    }

    public void setWorkstation(Workstation workstation) {
        this.workstation = workstation;
    }

    public Set<Project_Manager> getProjectsManager() {
        return projectsManager;
    }

    public void setProjectsManager(Set<Project_Manager> projectsManager) {
        this.projectsManager = projectsManager;
    }

    public User() {
    }
}
