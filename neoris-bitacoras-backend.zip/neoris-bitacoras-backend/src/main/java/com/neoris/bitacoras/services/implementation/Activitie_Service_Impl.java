package com.neoris.bitacoras.services.implementation;

import com.neoris.bitacoras.model.Activitie;
import com.neoris.bitacoras.repositories.Activitie_Repository;
import com.neoris.bitacoras.services.Activitie_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class Activitie_Service_Impl implements Activitie_Service {

    @Autowired
    private Activitie_Repository activitieRepository;

    @Override
    public Activitie saveActivitie(Activitie activitie) throws Exception {
        return activitieRepository.save(activitie);
    }

    @Override
    public Set<Activitie> listActivities() throws Exception {
        return new LinkedHashSet<>(activitieRepository.findAll());
    }

}
