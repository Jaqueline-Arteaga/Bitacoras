package com.neoris.bitacoras.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "AREAS",
       schema = "binnacle_activities",
       uniqueConstraints = {@UniqueConstraint(columnNames = {"name"})})

public class Area {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_area", length = 10)
    private int idArea;
    @Column(name = "name", nullable = false, length = 150)
    private String name;


    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "area")
    @JsonBackReference
    private Set<Activitie> activities= new HashSet<>();



    public int getIdArea() {
        return idArea;
    }

    public void setIdArea(int idArea) {
        this.idArea = idArea;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Activitie> getActivities() {
        return activities;
    }

    public void setActivities(Set<Activitie> activities) {
        this.activities = activities;
    }



    public Area() {
    }
}
