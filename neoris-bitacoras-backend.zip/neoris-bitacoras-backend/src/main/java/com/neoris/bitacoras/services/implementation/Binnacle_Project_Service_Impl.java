package com.neoris.bitacoras.services.implementation;

import com.neoris.bitacoras.model.Binnacle_Project;
import com.neoris.bitacoras.repositories.Binnacle_Project_Repository;
import com.neoris.bitacoras.services.Binnacle_Project_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class Binnacle_Project_Service_Impl implements Binnacle_Project_Service {

    @Autowired
    private Binnacle_Project_Repository binnacleProjectRepository;


    @Override
    public Binnacle_Project saveBinnacleProject(Binnacle_Project binnacleProject) throws Exception {
        return binnacleProjectRepository.save(binnacleProject);
    }

    @Override
    public Set<Binnacle_Project> listBinnaclesProjects() throws Exception {
        return new LinkedHashSet<>(binnacleProjectRepository.findAll());
    }

}
