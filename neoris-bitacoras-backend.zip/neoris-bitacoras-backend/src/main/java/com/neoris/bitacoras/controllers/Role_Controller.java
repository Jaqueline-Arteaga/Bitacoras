package com.neoris.bitacoras.controllers;

import com.neoris.bitacoras.model.Role;
import com.neoris.bitacoras.services.Role_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/ROLES")
@CrossOrigin("*")
public class Role_Controller {

    @Autowired
    private Role_Service roleService;

    @PostMapping("/")
    public ResponseEntity<Role> saveRole(@RequestBody Role role) throws Exception{
        Role roleSave = roleService.saveRole(role);
        return ResponseEntity.ok(roleSave);
    }

    @GetMapping("/")
    public ResponseEntity<?> listRoles() throws Exception{
        return ResponseEntity.ok(roleService.listRoles());
    }

}
