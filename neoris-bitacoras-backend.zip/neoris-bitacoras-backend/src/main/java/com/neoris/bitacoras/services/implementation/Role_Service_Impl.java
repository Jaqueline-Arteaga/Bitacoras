package com.neoris.bitacoras.services.implementation;

import com.neoris.bitacoras.model.Role;
import com.neoris.bitacoras.repositories.Role_Repository;
import com.neoris.bitacoras.services.Role_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class Role_Service_Impl implements Role_Service {

    @Autowired
    private Role_Repository roleRepository;

    @Override
    public Role saveRole(Role role) throws Exception {
        return roleRepository.save(role);
    }

    @Override
    public Set<Role> listRoles() throws Exception {
        return new LinkedHashSet<>(roleRepository.findAll());
    }

}
