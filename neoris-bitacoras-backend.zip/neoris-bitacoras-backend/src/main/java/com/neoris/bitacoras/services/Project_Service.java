package com.neoris.bitacoras.services;

import com.neoris.bitacoras.model.Project;

import java.util.Set;

public interface Project_Service {

    public Project saveProject(Project project) throws Exception;
    public Project updateProject(Project project, int idProject) throws Exception;
    public Set<Project> listProjects() throws Exception;
    public Project consultProject(int idProject) throws Exception;
    public void deleteProject(int idProject) throws Exception;

}
