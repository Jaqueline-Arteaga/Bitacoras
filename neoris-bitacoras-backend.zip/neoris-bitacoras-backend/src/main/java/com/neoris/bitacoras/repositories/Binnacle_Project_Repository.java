package com.neoris.bitacoras.repositories;

import com.neoris.bitacoras.model.Binnacle_Project;
import com.neoris.bitacoras.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Set;

public interface Binnacle_Project_Repository extends JpaRepository<Binnacle_Project,Integer> {

    public Binnacle_Project findById(int idBinPro) throws Exception;
    public Set<Binnacle_Project> findByProject(Project project) throws Exception;

}
