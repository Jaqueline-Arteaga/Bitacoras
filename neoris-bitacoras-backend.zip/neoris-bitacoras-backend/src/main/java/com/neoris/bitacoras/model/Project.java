package com.neoris.bitacoras.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "PROJECTS",
       schema = "binnacle_activities",
       uniqueConstraints = {@UniqueConstraint(columnNames = {"name","title"})})

public class Project {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_project", length = 10)
    private int idProject;
    @Column(name = "name", nullable = false, length = 150)
    private String name;
    @Column(name = "title", nullable = false, length = 150)
    private String title;
    @Column(name = "description", nullable = false, columnDefinition = "LONGTEXT")
    private String description;
    @Column(name = "working_hours", nullable = false, length = 10)
    private int workingHours;



    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "project")
    @JsonBackReference
    private Set<Project_Manager> projectsManager = new HashSet<>();

    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "project")
    @JsonBackReference
    private Set<Binnacle_Project> binnaclesProjects= new HashSet<>();




    public int getIdProject() {
        return idProject;
    }

    public void setIdProject(int idProject) {
        this.idProject = idProject;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(int workingHours) {
        this.workingHours = workingHours;
    }

    public Set<Project_Manager> getProjectsManager() {
        return projectsManager;
    }

    public void setProjectsManager(Set<Project_Manager> projectsManager) {
        this.projectsManager = projectsManager;
    }

    public Set<Binnacle_Project> getBinnaclesProjects() {
        return binnaclesProjects;
    }

    public void setBinnaclesProjects(Set<Binnacle_Project> binnaclesProjects) {
        this.binnaclesProjects = binnaclesProjects;
    }



    public Project() {
    }
}
