package com.neoris.bitacoras.repositories;

import com.neoris.bitacoras.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Project_Repository extends JpaRepository<Project,Integer> {

    public Project findById(int idProject) throws Exception;

}
