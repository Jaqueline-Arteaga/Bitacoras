package com.neoris.bitacoras.controllers;

import com.neoris.bitacoras.model.Binnacle;
import com.neoris.bitacoras.services.Binnacle_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/BINNACLES")
@CrossOrigin("*")
public class Binnacle_Controller {

    @Autowired
    private Binnacle_Service binnacleService;

    @PostMapping("/")
    public ResponseEntity<Binnacle> saveBinnacle(@RequestBody Binnacle binnacle) throws Exception{
        Binnacle binnacleSave = binnacleService.saveBinnacle(binnacle);
        return ResponseEntity.ok(binnacleSave);
    }

    @GetMapping("/{id_binnacle}")
    public Binnacle consultBinnacle(@PathVariable("id_binnacle") int idBinnacle) throws Exception{
        return binnacleService.consultBinnacle(idBinnacle);
    }

    @GetMapping("/")
    public ResponseEntity<?> listBinnacles() throws Exception{
        return ResponseEntity.ok(binnacleService.listBinnacles());
    }

    @PutMapping("/{id_binnacle}")
    public Binnacle updateBinnacle(@RequestBody Binnacle binnacle, @PathVariable("id_binnacle") int idBinnacle) throws Exception{
        return binnacleService.updateBinnacle(binnacle,idBinnacle);
    }

    @DeleteMapping("/{id_binnacle}")
    public void deleteBinnacle(@PathVariable("id_binnacle") int idBinnacle) throws Exception{
        binnacleService.deleteBinnacle(idBinnacle);
    }

}
