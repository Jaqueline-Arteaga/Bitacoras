package com.neoris.bitacoras.services;

import com.neoris.bitacoras.model.Provider;

import java.util.Set;

public interface Provider_Service {

    public Provider saveProvider(Provider provider) throws Exception;
    public Provider updateProvider(Provider provider, int idProvider) throws Exception;
    public Set<Provider> listProviders() throws Exception;
    public Provider consultProvider(int idProvider) throws Exception;
    public void deleteProvider(int idProvider) throws Exception;

}
